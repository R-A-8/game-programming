import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CannonBall here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CannonBall extends Actor
{
    private Vector2D velocity;
    
    public CannonBall()
    {
        
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
